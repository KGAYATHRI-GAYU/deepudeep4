document.addEventListener('DOMContentLoaded', function() {
    // Handle career form submission
    const careerForm = document.getElementById('career-form');
    if (careerForm) {
        careerForm.addEventListener('submit', handleFormSubmit);
    }

    // Handle contact form submission
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', handleFormSubmit);
    }

    function handleFormSubmit(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        const statusMessage = document.getElementById('status-message');
        const submitBtn = form.querySelector('.submit-btn');
        
        // Disable submit button during submission
        submitBtn.disabled = true;
        submitBtn.textContent = 'Sending...';
        
        fetch(form.action, {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                statusMessage.textContent = data.message;
                statusMessage.className = 'status-message success';
                form.reset();
                
                // Hide message after 5 seconds
                setTimeout(() => {
                    statusMessage.style.display = 'none';
                }, 5000);
            } else {
                statusMessage.textContent = data.message || 'An error occurred. Please try again.';
                statusMessage.className = 'status-message error';
            }
            statusMessage.style.display = 'block';
        })
        .catch(error => {
            statusMessage.textContent = 'An error occurred. Please try again.';
            statusMessage.className = 'status-message error';
            statusMessage.style.display = 'block';
            console.error('Error:', error);
        })
        .finally(() => {
            submitBtn.disabled = false;
            submitBtn.textContent = form.id === 'career-form' ? 'Submit Application' : 'Send Message';
            
            // Scroll to status message
            statusMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
    }
});