<?php
header('Content-Type: application/json');

// Validate and sanitize input
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

// Get form data
$formType = sanitizeInput($_POST['form_type'] ?? '');
$name = sanitizeInput($_POST['name'] ?? '');
$email = sanitizeInput($_POST['email'] ?? '');
$phone = sanitizeInput($_POST['phone'] ?? '');
$message = sanitizeInput($_POST['message'] ?? '');

// Additional fields for specific forms
$subject = '';
$position = '';

if ($formType === 'contact') {
    $subject = sanitizeInput($_POST['subject'] ?? '');
} elseif ($formType === 'career') {
    $position = sanitizeInput($_POST['position'] ?? '');
}

// Validate required fields
$requiredFields = ['name', 'email', 'message'];
if ($formType === 'contact') {
    $requiredFields[] = 'subject';
} elseif ($formType === 'career') {
    $requiredFields[] = 'position';
}

foreach ($requiredFields as $field) {
    if (empty($_POST[$field])) {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email format.']);
    exit;
}

// Set recipient email (replace with your business email)
$to = 'kgayu1717@gmail.com';

// Set email subject based on form type
$emailSubject = $formType === 'career' 
    ? "New Job Application: $position" 
    : "New Contact Message: $subject";

// Build email headers
$headers = "From: $email\r\n";
$headers .= "Reply-To: $email\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=UTF-8\r\n";

// Build email body
$emailBody = "
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background-color: #3498db; color: white; padding: 15px; text-align: center; }
        .content { padding: 20px; background-color: #f9f9f9; }
        .footer { padding: 10px; text-align: center; font-size: 12px; color: #777; }
        .field { margin-bottom: 15px; }
        .field-label { font-weight: bold; color: #2c3e50; }
    </style>
</head>
<body>
    <div class='container'>
        <div class='header'>
            <h2>" . ($formType === 'career' ? 'New Job Application' : 'New Contact Message') . "</h2>
        </div>
        <div class='content'>
            <div class='field'>
                <div class='field-label'>Name:</div>
                <div>$name</div>
            </div>
            <div class='field'>
                <div class='field-label'>Email:</div>
                <div>$email</div>
            </div>
            <div class='field'>
                <div class='field-label'>Phone:</div>
                <div>$phone</div>
            </div>";

if ($formType === 'career') {
    $emailBody .= "
            <div class='field'>
                <div class='field-label'>Position Applied For:</div>
                <div>$position</div>
            </div>";
} elseif ($formType === 'contact') {
    $emailBody .= "
            <div class='field'>
                <div class='field-label'>Subject:</div>
                <div>$subject</div>
            </div>";
}

$emailBody .= "
            <div class='field'>
                <div class='field-label'>" . ($formType === 'career' ? 'Cover Letter' : 'Message') . ":</div>
                <div>" . nl2br($message) . "</div>
            </div>
        </div>
        <div class='footer'>
            <p>This message was sent from the " . ($formType === 'career' ? 'career' : 'contact') . " form on your website.</p>
        </div>
    </div>
</body>
</html>
";

// Handle file upload for career form
$uploadedFile = '';
if ($formType === 'career' && isset($_FILES['resume']) && $_FILES['resume']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['resume'];
    
    // Validate file type
    $allowedTypes = [
        'application/pdf' => 'pdf',
        'application/msword' => 'doc',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx'
    ];
    
    $fileType = $file['type'];
    $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!array_key_exists($fileType, $allowedTypes) {
        echo json_encode(['success' => false, 'message' => 'Only PDF and DOC/DOCX files are allowed.']);
        exit;
    }
    
    // Validate file extension matches content type
    if ($allowedTypes[$fileType] !== $fileExt) {
        echo json_encode(['success' => false, 'message' => 'File extension does not match file type.']);
        exit;
    }
    
    // Validate file size (5MB max)
    if ($file['size'] > 5 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'File size must be less than 5MB.']);
        exit;
    }
    
    // Secure file name
    $fileName = preg_replace("/[^A-Za-z0-9._-]/", '_', basename($file['name']));
    $uploadPath = 'uploads/' . uniqid() . '_' . $fileName;
    
    // Create uploads directory if it doesn't exist
    if (!file_exists('uploads')) {
        mkdir('uploads', 0755, true);
    }
    
    // Move the file
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        $uploadedFile = $fileName;
        $emailBody .= "<div class='field'>
            <div class='field-label'>Resume:</div>
            <div>Attached: $fileName (Saved on server)</div>
        </div>";
    }
}

// Send email
$mailSent = mail($to, $emailSubject, $emailBody, $headers);

if ($mailSent) {
    echo json_encode([
        'success' => true, 
        'message' => $formType === 'career' 
            ? 'Thank you for your application! We will review your materials and get back to you soon.' 
            : 'Thank you for your message! We will get back to you soon.'
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to send message. Please try again later.']);
}
?>